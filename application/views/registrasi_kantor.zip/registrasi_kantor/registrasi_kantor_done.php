<div class="main-content" style="width:100%;">
    <div class="main-content-inner">
        <div class="page-content">
            <div class="row" style="margin-top:50px;">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <p>Terimakasih permohonan Anda sudah Kami terima silahkan tunggu secepatnya tim kami akan menghubungi</p>
                            <p>Untuk pertanyaan selanjutnya dapat menghubungi email: support@diengcyber.com atau di nomor wa +6285729670954</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3"></div>
            </div>
        </div>
    </div>
</div>